1. Download java runtime lasted version as below link
https://java.com/en/download/

2.Extract TennisTest.zip to folder destination.

3.You can edit input file at the "playGame.txt"

4. Double Click Tennis.bat

5.Program will popup result tennis scrore.


Thank you.